<script src="{{asset('assets/libs/jquery/dist/jquery.min.js')}}"></script>
<script src="{{asset('assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js')}}"></script>
<script src="{{asset('assets/js/sidebarmenu.js')}}"></script>
<script src="{{asset('assets/js/app.min.js')}}"></script>
<?php $routesIncludedTable = array('/'); ?>
@if(in_array(Request::path(), $routesIncludedTable))
<script src="{{asset('assets/libs/apexcharts/dist/apexcharts.min.js')}}"></script>
<script src="{{asset('assets/js/dashboard.js')}}"></script>
@endif
<script src="{{asset('assets/libs/simplebar/dist/simplebar.js')}}"></script>
